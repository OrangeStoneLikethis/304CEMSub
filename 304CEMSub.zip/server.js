var http = require('http');
var fs = require("fs");
var qs = require("querystring");
var MongoClient = require("mongodb").MongoClient;
var dbUrl = "mongodb://localhost:27017"


//create a server object:
http.createServer(function (req, res) {
    
	//Check Function
  if(req.url === "/apple"){
		res.write('Hello World!'); //write a response to the client
        res.end(); //end the response
		
		//Resgister Page
	}else if(req.url === "/register"){
		 console.log("client entered register page")
		sendFileContent(res, "register.html", "text/html");
		
		//Login Page
	}else if(req.url === "/login"){
		console.log("client entered login page")
		sendFileContent(res, "login.html", "text/html");
		
		//index Page
	}else if(req.url === "/index"){
		console.log("client entered index page")
		sendFileContent(res, "index.html", "text/html");
		
		//About Page
	}else if(req.url === "/about"){
		console.log("client entered about page")
		sendFileContent(res, "about.html", "text/html");
		
		//Product Page
	} else if(req.url === "/fav"){
		console.log("client entered item page")
		sendFileContent(res, "fav.html", "text/html");
		
		//Contact Page
	} else if(req.url === "/contact"){
		console.log("client entered contact page")
		sendFileContent(res, "contact.html", "text/html");
		
		//Login
		}
		else if(req.url === "/check_fav1"){
		console.log("Requested URL is url" +req.url);
	
		if(req.method==="POST"){
			formData = '';
			return req.on('data', function(data) {
				
			     fromData='';
					formData+=data;
					console.log(formData);
					
					//LUserN=777&LPass=iii
						return req.on('end', function(){
						
					var user;
					var pwd;
					var data;
					
					data=qs.parse(formData);
					user=data['LUserN'];
					pwd=data['LPass'];
					console.log("Check Login");
					
					
				
					//Login
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("AarrowMartdb");
							var query={"LUserN": user,"LPass":pwd};
							console.log(query);
							dbo.collection("arrowMartAcc").find(query).toArray(function(err, result) {
								if (err) throw err;
								console.log("comment find");
								console.log(JSON.stringify(result));
								db.close();
								return res.end(JSON.stringify(result));
							});
						});
					
					 });
					  });
 
			
		}else{
				
				
			    res.end(user+pwd);
			}	
		//Register
	}
		else if(req.url === "/check_fav2"){
		console.log("Requested URL is url" +req.url);
	
		if(req.method==="POST"){
			formData = '';
			return req.on('data', function(data) {
				
			     fromData='';
					formData+=data;
					console.log(formData);
					
					//LUserN=777&LPass=iii
						return req.on('end', function(){
						
					var user;
					var pwd;
					var data;
					
					data=qs.parse(formData);
					user=data['LUserN'];
					pwd=data['LPass'];
					console.log("Check");
					
					
				//set
					
					var query = {"LUserN": user,"LPass":pwd};
					//to database data
				
				
				//Registrarion

					MongoClient.connect(dbUrl, function(err,db){
					if (err) throw err;
					var dbo = db.db("AarrowMartdb");
							
							dbo.collection("arrowMartAcc").insertOne(query, function(err, res) {
								if (err) throw err;
								console.log("1 document inserted");
								 
								db.close();
							});
				});
					
					 });
					  });
 
			
		}else{
				
				
			    res.end(user+pwd);
			}	
		
		//fav List
		}else if(req.url === "/check_fav3"){
		console.log("Requested URL is url" +req.url);
	
		if(req.method==="POST"){
			formData = '';
			return req.on('data', function(data) {
				
			     fromData='';
					formData+=data;
					console.log(formData);
					
			return req.on('end', function(){
						
					var user;
					var itemid;
					var data;
					
					data=qs.parse(formData);
					user="user1";
					itemid=data['itemid'];
					console.log("Check");
					console.log(itemid);
					
					
				//set
					
					var query = {"user": user,"itemid":itemid};
					//to database data
				
				
				//Registrarion

					MongoClient.connect(dbUrl, function(err,db){
					if (err) throw err;
					var dbo = db.db("AarrowMartdb");
							
							dbo.collection("Favitem").insertOne(query, function(err, res) {
								if (err) throw err;
								console.log("1 document inserted");
								 
								db.close();
								//return res.end(JSON.stringify(query));
								
							});
				});
					
					 });
					  });
 
			
		}else{
					dbo.collection("Favitem").insertOne(query, function(err, res) {
								if (err) throw err;
								console.log("1 document inserted");
								 
								db.close();
				
			    res.end(user+itemid);
			});	
		}}
		
		
		//GET Action
		else if(req.url === "/check_fav4"){
		console.log("Requested URL is url" +req.url);
	
		if(req.method==="GET"){
			formData = '';
			return req.on('data', function(data) {
				
			     fromData='';
					formData+=data;
					console.log(formData);
					
					//LUserN=777&LPass=iii
						return req.on('end', function(){
						

					//Login
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("AarrowMartdb");
							var query={"user": user,"itemid":itemid};
							console.log(query);
							dbo.collection("Favitem").find(query).toArray(function(err, result) {
								if (err) throw err;
								console.log("comment find");
								console.log(JSON.stringify(result));
								db.close();
								return res.end(JSON.stringify(result));
							});
						});
					
					 });
					  });
 
			
		}else{
				
				
			    res.end(user+itemid);
			}
			
		}else if(/^\/[a-zA-Z0-9\/-/]*.js$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/javascript");
}else if(/^\/[a-zA-Z0-9\/-/]*.bundle.min.js$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/javascript");
}else if(/^\/[a-zA-Z0-9\/-/]*.css$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/css");
}else if(/^\/[a-zA-Z0-9\/-]*.min.css$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/css");
}else if(/^\/[a-zA-Z0-9\/-]*.jpg$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "image/jpg");
}else if(/^\/[a-zA-Z0-9-._\/]*.min.js$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/javascript");
}else if(/^\/[a-zA-Z0-9-]*.min.css.map$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/map");
}else if(/^\/[a-zA-Z0-9\/-/]*.min.js.map$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/map");
}else if(/^\/[a-zA-Z0-9\/-/]*.css.map$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/map");
}else if(/^\/[a-zA-Z0-9\/-/]*.png$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "image/png");
}else if(/^\/[a-zA-Z0-9\/-/]*.ico$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/ico");
}else if(/^\/[a-zA-Z0-9\/-/?]*.ttf$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/font");
}else if(/^\/[a-zA-Z0-9\/-/?]*.woff$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/woff");
}else if(/^\/[a-zA-Z0-9\/-/?]*.woff2$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/woff2");
}else{
console.log("Requested URL is: " + req.url);
res.end();
}
}).listen(8888); //the server object listens on port 8888


function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}